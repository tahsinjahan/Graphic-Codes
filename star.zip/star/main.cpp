#include <GL/gl.h>
#include <GL/glut.h>
void display(void)
{
/* clear all pixels */
glClear (GL_COLOR_BUFFER_BIT);
/* draw white polygon (rectangle) with corners at
* (0.25, 0.25, 0.0) and (0.75, 0.75, 0.0)
*/
glColor3ub (0, 0, 255);
glPointSize(50.0);
glBegin(GL_LINES);
glVertex2d (0, 210);
glVertex2d (400, 210);
glVertex2d (210, 0);
glVertex2d (210, 400);
glEnd();
glColor3ub (255, 0, 255);
/*left star */
glBegin(GL_QUADS);

glVertex2d (185, 190);
glVertex2d (185, 220);
glVertex2d (150, 220);
glVertex2d (150, 190);
glEnd();

glBegin(GL_TRIANGLES);

glVertex2d (150, 190);
glVertex2d (170, 160);
glVertex2d (185, 190);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (170, 250);
glVertex2d (150, 220);
glVertex2d (185, 220);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (150, 190);
glVertex2d (150, 220);
glVertex2d (123, 210);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (185, 190);
glVertex2d (210, 210);
glVertex2d (185, 220);

glEnd();

/*right star */
glColor3ub (0, 0, 0);
glBegin(GL_QUADS);

glVertex2d (275, 190);
glVertex2d (275, 220);
glVertex2d (240, 220);
glVertex2d (240, 190);
glEnd();

glBegin(GL_TRIANGLES);

glVertex2d (240, 220);
glVertex2d (275, 220);
glVertex2d (254, 250);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (275, 190);
glVertex2d (275, 220);
glVertex2d (305, 210);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (240, 190);
glVertex2d (240, 220);
glVertex2d (210, 210);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (240, 190);
glVertex2d (275, 190);
glVertex2d (254, 160);

glEnd();
/*top star */
glColor3ub (0, 255, 0);
glBegin(GL_QUADS);

glVertex2d (197, 240);
glVertex2d (220, 240);
glVertex2d (220, 273);
glVertex2d (197, 273);
glEnd();

glBegin(GL_TRIANGLES);

glVertex2d (197, 273);
glVertex2d (220, 273);
glVertex2d (210,305);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (220, 273);
glVertex2d (220, 243);
glVertex2d (254, 250);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (197, 243);
glVertex2d (220, 243);
glVertex2d (210, 210);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (197, 273);
glVertex2d (197, 240);
glVertex2d (170, 250);

glEnd();
/*bottom star */
glColor3ub (0, 0, 255);
glBegin(GL_QUADS);

glVertex2d (197, 142);
glVertex2d (220, 142);
glVertex2d (220, 172);
glVertex2d (197, 172);
glEnd();

glBegin(GL_TRIANGLES);

glVertex2d (197, 142);
glVertex2d (220, 142);
glVertex2d (210,92);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (197, 142);
glVertex2d (197, 172);
glVertex2d (169, 160);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (220, 142);
glVertex2d (220, 172);
glVertex2d (254, 160);

glEnd();
glBegin(GL_TRIANGLES);

glVertex2d (220, 172);
glVertex2d (197, 172);
glVertex2d (210, 210);

glEnd();
/* don't wait!
* start processing buffered OpenGL routines
*/
glFlush ();
}
void init (void)
{
/* select clearing (background) color */
glClearColor (1.0, 1.0, 1.0, 1.0);
/* initialize viewing values */
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0, 400, 0, 400);
}
/*
* Declare initial window size, position, and display mode
* (single buffer and RGBA). Open window with "hello"
* in its title bar. Call initialization routines.
* Register callback function to display graphics.
* Enter main loop and process events.
*/
int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (400, 400);
glutInitWindowPosition (100, 100);
glutCreateWindow ("Tahsin");
init ();
glutDisplayFunc(display);
glutMainLoop();
return 0; /* ISO C requires main to return int. */
}

