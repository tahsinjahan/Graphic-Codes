#include <GL/gl.h>
#include<GL\glut.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>
#define pi 3.142857
#include<iostream>
using namespace std;
float x = 100;
float y = 200;
float dy = 1.0;

void myInit()
{
    glClearColor(128.0f / 255.0f, 0, 0, 1.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 500, 0, 500, -10.0, 10.0);
}

void circle(float x, float y)
{
    float x1, y1, x2, y2;
    float radius = 100;

    x1 = x;
    y1 = y;

    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(253, 253, 229);
    glVertex2f(x1, y1);

    float angle;
    for (angle = 0; angle <= 360; angle += 0.5)
    {
        x2 = x1 + sin((angle * 3.1416) / 180) * radius;
        y2 = y1 + cos((angle * 3.1416) / 180) * radius;
        glVertex2f(x2, y2);
    }

    glEnd();
}
void circleRe(int x, int y, int r, int g, int b)
{
    float x1, y1, x2, y2;
    float radiusx = 550;
    float radiusy = 120;

    x1 = x;
    y1 = y;

    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(r, g, b);
    glVertex2f(x1, y1);

    float angle;
    for (angle = 0; angle <= 360; angle += 0.1)
    {
        int tx = rand() % 2;
        int ty = rand() % 70;
        x2 = tx + x1 + sin((angle * 3.1416) / 180) * radiusx;
        y2 = ty + y1 + cos((angle * 3.1416) / 180) * radiusy;
        glVertex2f(x2, y2);
    }

    glEnd();
}



void circle_kon(int h, int k, int rx,int ry)    //Works
{
    //glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer with current clearing color
    //glColor3f(1.0, .60, 0.0);
    glBegin(GL_POLYGON);
    for(int i=1; i<=360; i++)   //360 kon
    {
        //(x=position+radius x(150))    (y=position+radius y(150))   //// y point=sin main point ; x point=cos main point
        glVertex2f(h+rx*cos(3.14159*i/180),k+ry*sin(3.14159*i/180));       //main point + radius
    }                                                                      //3.14159*i/180   convert degree to radian


    glFlush();

}
void display(void)
{
/* clear all pixels */
glClear (GL_COLOR_BUFFER_BIT);
/* draw white polygon (rectangle) with corners at
* (0.25, 0.25, 0.0) and (0.75, 0.75, 0.0)
*/
//River
glColor3ub (100,149,237);
glBegin(GL_POLYGON);

glVertex2d (0,0);
glVertex2d (450,0);
glVertex2d (450,150);
glVertex2d (0,50);

glEnd();

//Boat

glColor3ub (0,0,128);
glBegin(GL_POLYGON);
glVertex2d (x+125,30);
glVertex2d (x+175,30);
glVertex2d (x+200,50);
glVertex2d (x+100,50);
glEnd();


//pal
glColor3ub (128,0,0);
glBegin(GL_POLYGON);
glVertex2d (x+150,52);
glVertex2d (x+150,75);
glVertex2d (x+85,52);
glEnd();

//line
glColor3ub (47,79,79);
glLineWidth(3);
glBegin(GL_LINES);
glVertex2d (x+155,50);
glVertex2d (x+155,76);
glVertex2d (x+165,50);
glVertex2d (x+165,76);
glEnd();




//Field
glColor3ub (154,205,50);
glBegin(GL_POLYGON);

glVertex2d (0,50);
glVertex2d (450,150);
glVertex2d (450,225);
glVertex2d (0,225);

glEnd();


//house 1


glColor3ub (255,69,0);
glBegin(GL_POLYGON);
glVertex2d (160,125);
glVertex2d (255,125);
glVertex2d (255,160);
glVertex2d (160,160);
glEnd();

glColor3ub (139,69,19);
glBegin(GL_POLYGON);
glVertex2d (150,160);
glVertex2d (265,160);
glVertex2d (255,180);
glVertex2d (160,180);
glEnd();

glColor3ub (72,61,139);
glBegin(GL_POLYGON);
glVertex2d (225,140);
glVertex2d (235,140);
glVertex2d (235,150);
glVertex2d (225,150);
glEnd();

glColor3ub (72,61,139);
glBegin(GL_POLYGON);
glVertex2d (175,140);
glVertex2d (185,140);
glVertex2d (185,150);
glVertex2d (175,150);
glEnd();

glColor3ub (72,61,139);
glBegin(GL_QUADS);
glVertex2d (200,125);
glVertex2d (220,125);
glVertex2d (220,150);
glVertex2d (200,150);
glEnd();






//house 2
glColor3ub (255,69,0);
glBegin(GL_POLYGON);
glVertex2d (100,100);
glVertex2d (170,100);
glVertex2d (170,150);
glVertex2d (100,150);
glEnd();

glColor3ub (139,69,19);
glBegin(GL_POLYGON);
glVertex2d (90,150);
glVertex2d (180,150);
glVertex2d (170,175);
glVertex2d (100,175);
glEnd();
//window 1
glColor3ub (72,61,139);
glBegin(GL_POLYGON);
glVertex2d (110,130);
glVertex2d (120,130);
glVertex2d (120,140);
glVertex2d (110,140);
glEnd();

glColor3ub (72,61,139);
glBegin(GL_POLYGON);
glVertex2d (150,130);
glVertex2d (160,130);
glVertex2d (160,140);
glVertex2d (150,140);
glEnd();

//door

glColor3ub (72,61,139);
glBegin(GL_QUADS);
glVertex2d (125,100);
glVertex2d (145,100);
glVertex2d (145,130);
glVertex2d (125,130);
glEnd();


//house 3

glColor3ub (72,209,204);
glBegin(GL_POLYGON);
glVertex2d (340,150);
glVertex2d (405,150);
glVertex2d (405,200);
glVertex2d (340,200);
glEnd();

glColor3ub (139,69,19);
glBegin(GL_POLYGON);
glVertex2d (330,200);
glVertex2d (415,200);
glVertex2d (405,220);
glVertex2d (340,220);
glEnd();
//window 1
glColor3ub (72,61,139);
glBegin(GL_POLYGON);
glVertex2d (350,175);
glVertex2d (365,175);
glVertex2d (365,185);
glVertex2d (350,185);
glEnd();

glColor3ub (72,61,139);
glBegin(GL_POLYGON);
glVertex2d (400,175);
glVertex2d (385,175);
glVertex2d (385,185);
glVertex2d (400,185);
glEnd();

//door

glColor3ub (72,61,139);
glBegin(GL_QUADS);
glVertex2d (370,150);
glVertex2d (380,150);
glVertex2d (380,175);
glVertex2d (370,175);
glEnd();


//sky
glColor3ub (0,206,209);
glBegin(GL_POLYGON);
glVertex2d (0,225);
glVertex2d (450,225);
glVertex2d (450,400);
glVertex2d (0, 400);
glEnd();


//hill 1
glColor3ub (210,105,30);
glBegin(GL_POLYGON);
glVertex2d (0,225);
glVertex2d (100, 225);
glVertex2d (50,275);
glVertex2d (0, 250);
glEnd();
//2
glColor3ub (210,105,30);
glBegin(GL_POLYGON);
glVertex2d (100,225);
glVertex2d (170,225);
glVertex2d (140,275);
glVertex2d (70,250);
glEnd();
//3
glColor3ub (210,105,30);
glBegin(GL_POLYGON);
glVertex2d (160,225);
glVertex2d (240,225);
glVertex2d (200,260);
glVertex2d (155,240);
glEnd();
//4
glColor3ub (210,105,30);
glBegin(GL_TRIANGLES);
glVertex2d (240,225);
glVertex2d (325,225);
glVertex2d (280,280);
glEnd();

//5

glColor3ub (210,105,30);
glBegin(GL_TRIANGLES);
glVertex2d (325,225);
glVertex2d (420,225);
glVertex2d (370,270);
glEnd();

//6

glColor3ub (210,105,30);
glBegin(GL_POLYGON);
glVertex2d (420,225);
glVertex2d (450,225);
glVertex2d (450,250);
glVertex2d (425,275);
glVertex2d (410,230);
glEnd();



//tree1
glColor3ub (153,76, 0);
glPointSize(50.0);
glBegin(GL_POLYGON);
glVertex2d (30, 175);
glVertex2d (30, 225);
glVertex2d (25,225);
glVertex2d (25,175);
glEnd();

glColor3ub (0,102, 0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (5, 225);
glVertex2d (30, 250);
glVertex2d (50,225);
glEnd();

glColor3ub (0,204, 0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (5, 235);
glVertex2d (30,260);
glVertex2d (50,235);
glEnd();



glColor3ub (51,255, 51);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (5, 245);
glVertex2d (30, 270);
glVertex2d (50,245);
glEnd();




//tree2
glColor3ub (153,76, 0);
glPointSize(50.0);
glBegin(GL_POLYGON);
glVertex2d (58,200);
glVertex2d (58,275);
glVertex2d (53,275);
glVertex2d (53,200);
glEnd();

glColor3ub (0,102, 0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (69, 275);
glVertex2d (56, 325);
glVertex2d (41,275);
glEnd();

//tree 3
glColor3ub (153,76, 0);
glPointSize(50.0);
glBegin(GL_POLYGON);
glVertex2d (100,200);
glVertex2d (105,200);
glVertex2d (105,250);
glVertex2d (100,250);
glEnd();

glColor3ub (0,102, 0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (80,250);
glVertex2d (125,250);
glVertex2d (100,300);
glEnd();




//tree 4
glColor3ub (139,69,19);
glPointSize(20.0);
glBegin(GL_POLYGON);
glVertex2d (295,140);
glVertex2d (305,140);
glVertex2d (305,175);
glVertex2d (295,175);
glEnd();

glColor3ub (0,100,0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (275,175);
glVertex2d (325,175);
glVertex2d (300,200);

glEnd();

glColor3ub (0,100,0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (275,185);
glVertex2d (325,185);
glVertex2d (300,220);
glEnd();


glColor3ub (0,100,0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (275,195);
glVertex2d (325,195);
glVertex2d (300,230);
glEnd();

//tree5

glColor3ub (139,69,19);
glPointSize(20.0);
glBegin(GL_POLYGON);
glVertex2d (180,210);
glVertex2d (190,210);
glVertex2d (190,250);
glVertex2d (180,250);
glEnd();


glColor3ub (0,100,0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (160,250);
glVertex2d (210,250);
glVertex2d (185,275);
glEnd();

glColor3ub (0,100,0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (160,260);
glVertex2d (210,260);
glVertex2d (185,280);
glEnd();


glColor3ub (0,100,0);
glPointSize(50.0);
glBegin(GL_TRIANGLES);
glVertex2d (160,270);
glVertex2d (210,270);
glVertex2d (185,300);
glEnd();

//sun
glColor3ub(255, 140, 0);
circle_kon(350, 350, 25, 25);

glEnd();

//cloud1


x += dy;

if (x >= 300 || x <= 100)
dy *= -1;

glColor3ub(255, 255, 255);
circle_kon(x+50, 350, 20, 20);

glEnd();


glColor3ub(255, 255, 255);
circle_kon(x+60, 340, 20, 20);

glEnd();
glColor3ub(255, 255, 255);
circle_kon(x+25, 330, 20, 20);

glEnd();

//cloud2
glColor3ub(255, 255, 255);
circle_kon(x+150, 350, 20, 20);

glEnd();

glColor3ub(255, 255, 255);
circle_kon(x+160, 330, 20, 20);

glColor3ub(255, 255, 255);
circle_kon(x+140, 325, 20, 20);

glEnd();


glFlush ();
}


void init (void)
{
/* select clearing (background) color */
glClearColor (0.0, 0.0, 0.0, 0.0);
/* initialize viewing values */
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0, 400, 0, 400);

}

void update(int val)
{
    glutPostRedisplay();
    glutTimerFunc(40, update, 0);
}


int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (1000, 700);
glutInitWindowPosition (0, 0);
glutCreateWindow ("Natural Scene");
init();
glutDisplayFunc(display);
glutTimerFunc(45, update, 0);
update(0);
glutMainLoop();
return 0;
}
