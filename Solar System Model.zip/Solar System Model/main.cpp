#include <stdio.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>

float r, x, y, theta;
float m = 0, v = 0, e = 0, mr = 0, j = 0, s = 0, u = 0, n = 0;
float mercury_x = 200;
float mercury_y = 100;
float venus_x = 400;
float venus_y = 50;
float earth_x = 600;
float earth_y = 30;
float mars_x = -800;
float mars_y = 90;
float jupiter_x = 1000;
float jupiter_y = 100;
float saturn_x = -1200;
float saturn_y = 300;
float uranus_x = 1400;
float uranus_y = 20;
float neptune_x = -1500;
float neptune_y = 500;
void timer(int);

void display(void)
{
    glClear (GL_COLOR_BUFFER_BIT);

    //10 random star at each frame
    for(int z =0; z <= 10; z++)
    {
        int zx = rand() % 3400 - 1700;
        int zy = rand() % 3400 - 1700;
        glPointSize(5);
        glBegin(GL_POINTS);
        glColor3ub(255,255,255);
        glVertex2f(zx, zy);
    }
    r = 1600;
    for(int j=0; j<8; j++)
    {
        for(int i=0; i<=360;i++)
        {
            glPointSize(2);
            glBegin(GL_POINTS);
                glColor3ub (255, 255, 255);

                theta = i*3.142/180;
                glVertex2f(r*cos(theta), r*sin(theta));
            glEnd();
        }
        r -=200;
    }

    //sun


    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(254,204,25); //Center Color of Circle;


    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(80*cos(theta), 80*sin(theta));
    }
    glEnd();


    //mercury
    glBegin(GL_POLYGON);
    glColor3ub(204,126,56);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(50*cos(theta) + mercury_x, 50*sin(theta) + mercury_y);
    }
    glEnd();

    //venus
    glBegin(GL_POLYGON);
    glColor3ub(215,122,98);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(80*cos(theta) + venus_x, 80*sin(theta) + venus_y);
    }
    glEnd();

    //earth
    glBegin(GL_POLYGON);
    glColor3ub(70,248,202);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(80*cos(theta) +earth_x, 80*sin(theta) +earth_y);
    }
    glEnd();


    //mars
    glBegin(GL_POLYGON);
    glColor3ub(198,62,60);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(70*cos(theta) +mars_x, 70*sin(theta) +mars_y);
    }
    glEnd();

    //jupiter
    glBegin(GL_POLYGON);
    glColor3ub(214,206,158);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(120*cos(theta) +jupiter_x, 120*sin(theta) + jupiter_y);
    }
    glEnd();

    //saturn
    glBegin(GL_POLYGON);
    glColor3ub(231,203,191);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(130*cos(theta) + saturn_x, 60*sin(theta) +saturn_y);
    }
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(37,9,50);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(110*cos(theta) + saturn_x, 50*sin(theta) +saturn_y);
    }
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(227,197,101);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(90*cos(theta) +saturn_x, 90*sin(theta) +saturn_y);
    }
    glEnd();

    //uranus
    glBegin(GL_POLYGON);
    glColor3ub(36,97,253);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(80*cos(theta) +uranus_x, 80*sin(theta) +uranus_y);
    }
    glEnd();

    //neptune
    glBegin(GL_POLYGON);
    glColor3ub(153,223,254);
    for(int i = 0; i <= 360; i++)
    {
        theta = i*3.142/180;
        glVertex2f(80*cos(theta) + neptune_x, 80*sin(theta) + neptune_y);
    }
    glEnd();



    glutSwapBuffers();
}

void init (void)
{
    glClearColor (0.142, 0.0353, 0.196, 0.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1700, 1700, -1700, 1700);

}


int main(int argc, char** argv)
{

    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize (700, 700);
    glutInitWindowPosition (100, 0);
    glutCreateWindow ("Solar System Model");
    init ();
    glutDisplayFunc(display);

    glutMainLoop();

}


