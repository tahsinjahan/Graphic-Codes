#include <GL/gl.h>
#include<GL\glut.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>
void init(void)
{
    glClearColor(0.0, 0.0, 0.0, 0.0);
    gluOrtho2D(0, 600, 0, 600);
}



void circle_kon(int h, int k, int rx,int ry)
{
    glBegin(GL_POLYGON);
    for(int i=1; i<=360; i++)
    {
        glVertex2f(h+rx*cos(3.14159*i/180),k+ry*sin(3.14159*i/180));
    }

    glFlush();

}


void buildHouse(void)
{
glColor3ub (0,128, 0);
glLineWidth(10);
glBegin(GL_LINES);
glVertex2d (200, 0);
glVertex2d (200, 150);
glEnd();

glColor3ub (255, 215, 0);
circle_kon(245, 205, 30, 30);
glEnd();

glColor3ub (255, 215, 0);
circle_kon(225, 250, 30, 30);
glEnd();

glColor3ub (255, 215, 0);
circle_kon(170, 250, 30, 30);
glEnd();

glColor3ub (255, 215, 0);
circle_kon(145, 205, 30, 30);
glEnd();

glColor3ub (0, 128, 0);
circle_kon(250, 100, 50, 30);
glEnd();

glColor3ub (255, 0,0);
circle_kon(200, 200, 50, 50);
glEnd();

glFlush();

}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowPosition(0, 0);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Flower");
    init();
    glutDisplayFunc(buildHouse);
    glutMainLoop();
}
